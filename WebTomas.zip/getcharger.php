<?php
// Incluir archivo de conexión a la base de datos
require 'conexion.php';

// Verificar si los parámetros lat y lng están presentes en la URL
if (!isset($_GET['lat']) || !isset($_GET['lng'])) {
    // Si faltan los parámetros, devolver un error en formato JSON
    echo json_encode(['error' => 'Faltan los parámetros de latitud y longitud.']);
    exit;
}

// Obtener las coordenadas del usuario (latitud y longitud) desde los parámetros de la URL
$lat = floatval($_GET['lat']);
$lng = floatval($_GET['lng']);

// Validar que las coordenadas sean números válidos
if ($lat == 0 || $lng == 0) {
    echo json_encode(['error' => 'Las coordenadas proporcionadas no son válidas.']);
    exit;
}

// Consulta SQL para obtener los cargadores cercanos dentro de un radio de 50 km
$sql = "
    SELECT id, nombre, direccion, latitud, longitud, tipo_cargador,
    (6371 * acos(cos(radians($lat)) * cos(radians(latitud)) * cos(radians(longitud) - radians($lng)) + 
    sin(radians($lat)) * sin(radians(latitud)))) AS distance
    FROM ubicaciones_cargadores
    HAVING distance < 50
    ORDER BY distance
";

// Ejecutar la consulta y manejar posibles errores
$result = $conn->query($sql);

if (!$result) {
    echo json_encode(['error' => 'Error en la consulta a la base de datos: ' . $conn->error]);
    $conn->close();
    exit;
}

// Obtener los cargadores en un array
$cargadores = [];
while ($row = $result->fetch_assoc()) {
    $cargadores[] = $row;
}

// Devolver los cargadores como JSON
echo json_encode(['cargadores' => $cargadores]);

// Cerrar la conexión a la base de datos
$conn->close();
?>

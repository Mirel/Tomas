<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <!-- Logo y nombre del sitio -->
        <a class="navbar-brand" href="index.php">TOMAS</a>

        <!-- Botón de la barra de navegación para pantallas pequeñas -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menú de navegación -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <!-- Enlace a la página de inicio -->
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">Inicio</a>
                </li>

                <!-- Enlace a la página de cuenta de usuario -->
                <li class="nav-item">
                    <a class="nav-link" href="micuenta.php">Mi cuenta</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

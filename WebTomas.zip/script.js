let map;
let userMarker;
let markers = []; // Array para almacenar los marcadores

function initMap() {
    const madrid = { lat: 40.4168, lng: -3.7038 }; // Coordenadas de Madrid

    initializeMap(madrid);
    configureSearchBox();
    findElectricChargers(madrid, 50000); // Buscar cargadores en un radio de 50 km
}

/**
 * Inicializa el mapa centrado en una ubicación específica.
 * @param {Object} center - Coordenadas { lat, lng } para centrar el mapa.
 */
function initializeMap(center) {
    map = new google.maps.Map(document.getElementById("map"), {
        center: center,
        zoom: 13,
        mapTypeControl: true,
        fullscreenControl: true,
        streetViewControl: true,
    });
}

/**
 * Configura la barra de búsqueda en el mapa.
 */
function configureSearchBox() {
    const searchInput = document.getElementById("search-box");
    const searchBox = new google.maps.places.SearchBox(searchInput);

    // Agregar la barra de búsqueda al mapa
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(searchInput);

    // Manejar eventos de búsqueda
    searchBox.addListener("places_changed", () => {
        const places = searchBox.getPlaces();
        if (!places || places.length === 0) return;

        clearMarkers();
        adjustMapBounds(places);
    });
}

/**
 * Ajusta los límites del mapa y coloca marcadores en los lugares encontrados.
 * @param {Array} places - Lugares encontrados en la búsqueda.
 */
function adjustMapBounds(places) {
    const bounds = new google.maps.LatLngBounds();

    places.forEach(place => {
        if (!place.geometry || !place.geometry.location) return;

        addMarker(place.geometry.location, place.name);
        bounds.extend(place.geometry.location);
    });

    map.fitBounds(bounds);
}

/**
 * Busca estaciones de carga eléctrica cercanas.
 * @param {Object} location - Coordenadas { lat, lng } para la búsqueda.
 * @param {number} radius - Radio de búsqueda en metros.
 */
function findElectricChargers(location, radius) {
    const service = new google.maps.places.PlacesService(map);

    service.nearbySearch(
        {
            location: location,
            radius: radius,
            keyword: "electric vehicle charging station",
        },
        handleChargerResults
    );
}

/**
 * Maneja los resultados de la búsqueda de cargadores eléctricos.
 * @param {Array} results - Resultados de la búsqueda.
 * @param {string} status - Estado de la búsqueda.
 */
function handleChargerResults(results, status) {
    if (status !== google.maps.places.PlacesServiceStatus.OK) {
        console.error("Error al buscar cargadores eléctricos:", status);
        return;
    }

    if (!results || results.length === 0) {
        console.warn("No se encontraron cargadores eléctricos en el área especificada.");
        return;
    }

    clearMarkers();
    results.forEach(place => {
        if (place.geometry && place.geometry.location) {
            addMarkerWithInfoWindow(
                place.geometry.location,
                place.name,
                place.vicinity
            );
        }
    });
}

/**
 * Agrega un marcador simple al mapa.
 * @param {Object} position - Coordenadas { lat, lng } del marcador.
 * @param {string} title - Título del marcador.
 */
function addMarker(position, title) {
    const marker = new google.maps.Marker({
        position: position,
        map: map,
        title: title,
    });
    markers.push(marker);
}

/**
 * Agrega un marcador con un InfoWindow al mapa.
 * @param {Object} position - Coordenadas { lat, lng } del marcador.
 * @param {string} title - Título del marcador.
 * @param {string} vicinity - Ubicación cercana del lugar.
 */
function addMarkerWithInfoWindow(position, title, vicinity) {
    const marker = new google.maps.Marker({
        position: position,
        map: map,
        title: title,
        icon: {
            url: "https://maps.google.com/mapfiles/ms/icons/green-dot.png",
        },
    });

    const infowindow = new google.maps.InfoWindow({
        content: `<div><strong>${title}</strong><br>${vicinity}</div>`,
    });

    marker.addListener("click", () => infowindow.open(map, marker));
    markers.push(marker);
}

/**
 * Limpia todos los marcadores del mapa.
 */
function clearMarkers() {
    markers.forEach(marker => marker.setMap(null));
    markers = [];
}

/**
 * Centra el mapa en la ubicación del usuario, si está disponible.
 */
function centerMapOnUser() {
    if (!navigator.geolocation) {
        alert("La geolocalización no está soportada por tu navegador.");
        return;
    }

    navigator.geolocation.getCurrentPosition(
        (position) => {
            const userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
            };

            map.setCenter(userLocation);
            map.setZoom(14);

            if (!userMarker) {
                userMarker = new google.maps.Marker({
                    position: userLocation,
                    map: map,
                    title: "Tu ubicación",
                    icon: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                });
            } else {
                userMarker.setPosition(userLocation);
            }
        },
        (error) => handleGeolocationError(error)
    );
}

/**
 * Maneja errores de geolocalización.
 * @param {Object} error - Error de geolocalización.
 */
function handleGeolocationError(error) {
    const errorMessages = {
        [error.PERMISSION_DENIED]: "El permiso de ubicación fue denegado.",
        [error.POSITION_UNAVAILABLE]: "La ubicación no está disponible.",
        [error.TIMEOUT]: "La solicitud de ubicación ha expirado.",
        [error.UNKNOWN_ERROR]: "Ha ocurrido un error desconocido.",
    };

    alert(errorMessages[error.code] || "Error al obtener la ubicación.");
}
<?php
// Comprobar si se envió el formulario mediante POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Mostrar errores de PHP para depuración (solo en desarrollo)
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Incluir la conexión a la base de datos
    require 'conexion.php';

    // Obtener datos del formulario
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_BCRYPT); // Cifrar la contraseña

    // Verificar si el correo ya está registrado
    $sql_check = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql_check);
    $stmt->bind_param("s", $email); // Enlazar el parámetro
    $stmt->execute();
    $result = $stmt->get_result();

    // Si el correo ya está registrado
    if ($result->num_rows > 0) {
        echo "<script>alert('Este correo electrónico ya está registrado.');</script>";
    } else {
        // Insertar en la base de datos utilizando una consulta preparada
        $sql = "INSERT INTO usuarios (nombre, apellidos, fecha_nacimiento, telefono, email, contrasena)
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $nombre, $apellidos, $fecha_nacimiento, $telefono, $email, $contrasena); // Enlazar los parámetros

        // Ejecutar la consulta
        if ($stmt->execute()) {
            // Iniciar sesión automáticamente
            session_start();
            $_SESSION['usuario'] = $nombre;  // Guardar el nombre del usuario en la sesión

            // Redirigir al área de la cuenta del usuario o a otra página
            header("Location: micuenta.php");
            exit(); // Asegúrate de que el script termine aquí
        } else {
            // Mostrar un mensaje de error si la inserción falla
            echo "<script>alert('Error al registrar: " . $stmt->error . "');</script>";
        }

        // Cerrar la declaración
        $stmt->close();
    }

    // Cerrar la conexión a la base de datos
    $conn->close();
}
?>

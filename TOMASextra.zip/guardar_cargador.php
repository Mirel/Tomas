<?php
// Conexión a la base de datos
include 'conexion.php';

// Obtener los datos JSON enviados desde JavaScript
$data = json_decode(file_get_contents("php://input"));

// Obtener los datos del cargador
$name = $data->name;
$location = $data->location;
$lat = $data->lat;
$lng = $data->lng;

// Inserción en la tabla 'reservas'
$sqlInsertReserva = "INSERT INTO reservas (nombre_cargador, ubicacion, lat, lng, estado_reserva) 
                     VALUES (?, ?, ?, ?, 'Disponible')";
$stmtReserva = $conn->prepare($sqlInsertReserva);
$stmtReserva->bind_param("ssdd", $name, $location, $lat, $lng);
$stmtReserva->execute();

// Inserción en la tabla 'preDisponible'
$precio = rand(25, 45) / 100;  // Generar precio aleatorio
$disponibilidad = rand(0, 1) ? 'Disponible' : 'No disponible'; // Aleatorio

$sqlInsertDisponible = "INSERT INTO preDisponible (nombre_cargador, lat, lng, precio, disponibilidad)
                        VALUES (?, ?, ?, ?, ?)";
$stmtDisponible = $conn->prepare($sqlInsertDisponible);
$stmtDisponible->bind_param("sddds", $name, $lat, $lng, $precio, $disponibilidad);
$stmtDisponible->execute();

// Devolver respuesta al cliente
echo json_encode(['status' => 'success', 'message' => 'Cargador guardado correctamente']);
?>

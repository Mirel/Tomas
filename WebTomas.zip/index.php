<?php
// Inicia sesión
session_start();
$apiKey = 'KEY-API-GOOGLE'; // Clave de la API de Google Maps (reemplazar por una variable de entorno en producción)

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TOMAS - Estaciones de carga eléctrica</title>

    <!-- Vincula los recursos externos de CSS y JS de forma eficiente -->
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons para íconos -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Archivo de estilos personalizados -->
    <link rel="stylesheet" href="estilos.css">

    <!-- Google Maps API con la clave de la API (reemplazar por una variable de entorno en producción) -->
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo $apiKey; ?>&libraries=places&callback=initMap" async defer></script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery (para la compatibilidad con otros scripts si es necesario) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Archivo JavaScript personalizado -->
    <script src="script.js" defer></script>
</head>

<body>
    <!-- Navbar: encabezado de navegación -->
    <?php include 'header.php'; ?>

    <!-- Contenedor de búsqueda -->
    <section id="search-container" class="d-flex justify-content-center mt-3">
        <input id="search-box" type="text" class="form-control" placeholder="Buscar ubicación (ciudad, barrio, código postal)">
        <button id="search-btn" class="btn btn-primary">
            <i class="bi bi-search"></i> <!-- Ícono de lupa -->
        </button>
    </section>


    <!-- Google Maps como fondo -->
    <div id="map"></div>

    <!-- Botón para centrar el mapa en la ubicación del usuario -->
    <div id="compass-btn" class="position-fixed bottom-0 end-0 mb-3 me-3" onclick="centerMap()">
        <i class="bi bi-compass" style="font-size: 2rem;"></i>
    </div>

</body>

</html>
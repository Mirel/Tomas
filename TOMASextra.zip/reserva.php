<?php
session_start();
include 'conexion.php'; // Conexión a la base de datos

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // Para manejar errores de MySQL

// 1️⃣ Capturar y validar parámetros GET
$name = $_GET['name'] ?? '';
$location = $_GET['location'] ?? '';

if (empty($name) || empty($location)) {
    die("Error: Parámetros inválidos.");
}

// 2️⃣ Consultar información del cargador
try {
    $sql = "SELECT r.*, p.precio, p.disponibilidad
            FROM reservas r
            LEFT JOIN preDisponible p ON r.id = p.id_reserva
            WHERE r.nombre_cargador = ? AND r.ubicacion = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $name, $location);
    $stmt->execute();
    $result = $stmt->get_result();
    $cargador = $result->fetch_assoc();
    
    if (!$cargador) {
        die("Error: Cargador no encontrado.");
    }

    $estado_reserva = $cargador['fecha_reserva'] ? "Reservado" : "Disponible";
} catch (Exception $e) {
    die("Error al obtener la información: " . $e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserva de Cargador</title>
    <link rel="stylesheet" href="estilos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="script.js" defer></script>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="indexArea.php">TOMAS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['nombre'])): ?>
                        <li class="nav-item">
                            <span class="nav-link text-white">Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Cerrar Sesión</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="micuenta.php">Iniciar Sesión</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center">Reserva tu cargador</h2>
        <div class="card mx-auto">
            <div class="card-header">
                <h4>Información del Cargador</h4>
            </div>
            <div class="card-body">
                <p><strong>Nombre del Cargador:</strong> <?php echo htmlspecialchars($cargador['nombre_cargador']); ?></p>
                <p><strong>Ubicación:</strong> <?php echo htmlspecialchars($cargador['ubicacion']); ?></p>
                <p><strong>Precio por kWh:</strong> <?php echo number_format($cargador['precio'], 2); ?> €/kWh</p>
                <p><strong>Disponibilidad:</strong> <?php echo htmlspecialchars($cargador['disponibilidad']); ?></p>
            </div>
            <div class="card-footer text-center">
                <p>Estado actual: <strong><?php echo $estado_reserva; ?></strong></p>

                <?php if ($cargador['disponibilidad'] === 'Disponible' && !$cargador['fecha_reserva']): ?>
                    <form action="" method="POST">
                        <input type="hidden" name="cargador_nombre" value="<?php echo htmlspecialchars($cargador['nombre_cargador']); ?>">
                        <input type="hidden" name="cargador_ubicacion" value="<?php echo htmlspecialchars($cargador['ubicacion']); ?>">
                        <input type="hidden" name="precio" value="<?php echo htmlspecialchars($cargador['precio']); ?>">
                        <input type="hidden" name="disponibilidad" value="<?php echo htmlspecialchars($cargador['disponibilidad']); ?>">
                        <input type="hidden" name="user_location" id="user_location">
                        <button type="submit" class="btn btn-primary" onclick="setLocation()">Reservar</button>
                    </form>
                <?php elseif ($cargador['fecha_reserva']): ?>
                    <button class="btn btn-secondary" disabled>Reservado</button>
                <?php endif; ?>
            </div>
        </div>
    </div>

</body>
</html>

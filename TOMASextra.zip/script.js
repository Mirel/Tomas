let map;
let userMarker;
let markers = []; // Array para almacenar los marcadores
let directionsService;
let directionsRenderer;

function initMap() {
    const madrid = { lat: 40.4168, lng: -3.7038 }; // Coordenadas de Madrid

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer();
    directionsRenderer.setMap(map);

    initializeMap(madrid);
    configureSearchBox();
    findElectricChargers(madrid, 50000); // Buscar cargadores en un radio de 50 km
    // Escucha el clic del botón para centrar el mapa
    document.getElementById("compass-btn").addEventListener("click", centerMap);
}

/**
 * Inicializa el mapa centrado en una ubicación específica.
 * @param {Object} center - Coordenadas { lat, lng } para centrar el mapa.
 */
function initializeMap(center) {
    map = new google.maps.Map(document.getElementById("map"), {
        center: center,
        zoom: 13,
        mapTypeControl: true,
        fullscreenControl: true,
        streetViewControl: true,
    });
}

/**
 * Configura la barra de búsqueda en el mapa.
 */
function configureSearchBox() {
    const searchInput = document.getElementById("search-box");

    if (!searchInput) {
        console.error("No se encontró el campo de búsqueda.");
        return;
    }

    const searchBox = new google.maps.places.SearchBox(searchInput);

    // Agregar la barra de búsqueda al mapa
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(searchInput);

    // Manejar eventos de búsqueda
    searchBox.addListener("places_changed", () => {
        const places = searchBox.getPlaces();
        if (!places || places.length === 0) {
            console.warn("No se encontraron lugares.");
            return;
        }

        clearMarkers();
        adjustMapBounds(places);
    });

    console.log("Barra de búsqueda configurada correctamente.");
}

// Llamar a la función cuando el mapa esté listo
google.maps.event.addDomListener(window, "load", configureSearchBox);


/**
 * Ajusta los límites del mapa y coloca marcadores en los lugares encontrados.
 * @param {Array} places - Lugares encontrados en la búsqueda.
 */
function adjustMapBounds(places) {
    const bounds = new google.maps.LatLngBounds();

    places.forEach(place => {
        if (!place.geometry || !place.geometry.location) return;
        addMarkerWithInfoWindow(place.geometry.location, place.name, place.vicinity);
        bounds.extend(place.geometry.location);
    });

    map.fitBounds(bounds);
}

/**
 * Busca estaciones de carga eléctrica cercanas.
 */
// Función para buscar cargadores eléctricos
function findElectricChargers(location) {
    const service = new google.maps.places.PlacesService(map);

    service.nearbySearch(
        {
            location: location,
            radius: 50000, // 50 km
            keyword: "electric vehicle charging station", // Palabra clave para la búsqueda de cargadores
        },
        (results, status) => {
            if (status === google.maps.places.PlacesServiceStatus.OK) {
                markers.forEach(marker => marker.setMap(null)); // Limpiar los marcadores previos
                markers = [];

                results.forEach(place => {
                    if (place.geometry && place.geometry.location) {
                        const marker = new google.maps.Marker({
                            position: place.geometry.location,
                            map: map,
                            title: place.name,
                            icon: {
                                url: "https://maps.google.com/mapfiles/ms/icons/green-dot.png", // Icono verde
                            },
                        });

                        const infowindow = new google.maps.InfoWindow({
                            content: `
                                <div>
                                    <strong>${place.name}</strong><br>
                                    ${place.vicinity}<br>
                                    <!-- Botón para redirigir a la página reserva.php con los parámetros del cargador -->
                                    <a href="reserva.php?name=${encodeURIComponent(place.name)}&location=${encodeURIComponent(place.vicinity)}&lat=${place.geometry.location.lat()}&lng=${place.geometry.location.lng()}">
                                        <button>Reservar</button>
                                    </a>
                                </div>
                            `,
                        });

                        marker.addListener("click", () => {
                            infowindow.open(map, marker); // Mostrar el infowindow al hacer clic en la chincheta
                        });

                        markers.push(marker); // Agregar el marcador a la lista
                    }
                });
            } else {
                console.error("Error al buscar cargadores eléctricos:", status); // Manejo de error en la búsqueda
            }
        }
    );
}


/**
 * Centra el mapa en la ubicación del usuario, si está disponible.
 */
function centerMap() {
    if (!navigator.geolocation) {
        alert("La geolocalización no está soportada por tu navegador.");
        return;
    }

    navigator.geolocation.getCurrentPosition(
        (position) => {
            const userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
            };

            console.log("Ubicación del usuario:", userLocation);

            // Asegúrate de que el mapa esté inicializado
            if (map) {
                // Centrar el mapa en la ubicación del usuario
                map.setCenter(userLocation);
                map.setZoom(14);

                // Crear o actualizar el marcador del usuario
                if (!userMarker) {
                    userMarker = new google.maps.Marker({
                        position: userLocation,
                        map: map,
                        title: "Tu ubicación",
                        icon: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                    });
                } else {
                    userMarker.setPosition(userLocation);
                }
            } else {
                console.error("El mapa no está inicializado.");
            }
        },
        (error) => handleGeolocationError(error),
        {
            enableHighAccuracy: true,
            timeout: 10000, // Esperar hasta 10 segundos
            maximumAge: 0, // No usar datos de ubicación en caché
        }
    );
}

/**
 * Maneja errores de geolocalización.
 * @param {Object} error - Error de geolocalización.
 */
function handleGeolocationError(error) {
    alert("Error de geolocalización: " + (error.message || "Desconocido"));
}
function reserveCharger(lat, lng) {
    if (!navigator.geolocation) {
        alert("La geolocalización no está soportada por tu navegador.");
        return;
    }

    navigator.geolocation.getCurrentPosition(
        (position) => {
            const userLocation = { lat: position.coords.latitude, lng: position.coords.longitude };
            calculateRoute(userLocation, { lat, lng });
        },
        (error) => handleGeolocationError(error),
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
}


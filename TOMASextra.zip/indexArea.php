<?php
// Inicia sesión
session_start();
$apiKey = ''; // Clave de la API de Google Maps (reemplazar por una variable de entorno en producción)

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    // Si no está logueado, redirigir al login
    header("Location: micuenta.php");
    exit();
}

// Obtener datos del usuario desde la sesión
$nombre = isset($_SESSION['nombre']) ? $_SESSION['nombre'] : '';
$apellidos = isset($_SESSION['apellidos']) ? $_SESSION['apellidos'] : '';
$email = isset($_SESSION['email']) ? $_SESSION['email'] : '';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TOMAS - Estaciones de carga eléctrica</title>

    <!-- Vincula los recursos externos de CSS y JS de forma eficiente -->
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons para íconos -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Archivo de estilos personalizados -->
    <link rel="stylesheet" href="estilos.css">

    <!-- Google Maps API con la clave de la API (reemplazar por una variable de entorno en producción) -->
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo $apiKey; ?>&libraries=places&callback=initMap" async defer></script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery (para la compatibilidad con otros scripts si es necesario) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Archivo JavaScript personalizado -->
    <script src="script.js" defer></script>
</head>

<body>
    <!-- Navbar: encabezado de navegación -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="indexArea.php">TOMAS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['nombre'])): ?>
                        <li class="nav-item">
                            <span class="nav-link text-white">Bienvenido, <?php echo htmlspecialchars($nombre); ?></span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Cerrar Sesión</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="micuenta.php">Iniciar Sesión</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Contenedor de búsqueda -->
    <section id="search-container">
        <input id="search-box" type="text" placeholder="Buscar ubicación (ciudad, barrio, código postal)">
        <button id="search-btn">
            <i class="bi bi-search"></i> <!-- Ícono de lupa -->
        </button>
    </section>



    <!-- Google Maps como fondo -->
    <div id="map"></div>

    <!-- Botón para centrar el mapa en la ubicación del usuario -->
    <div id="compass-btn" onclick="centerMap()">
        <i class="bi bi-compass"></i>
    </div>

</body>

</html>